using System;

namespace Lab2V17
{
    class Program
    {
        // Варіант 17
        // N = 17
        // Ім'я: Павло
        // П = 20-та літера української абетки
        // a = N % 3 = 2
        // b = N % 4 = 1
        // c = N % 5 = 2

        const int N = 17;
        const int K = 20;

        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("Лабораторна робота 2");
            Console.WriteLine("Алгоритми обробки масивів");
            Console.WriteLine("Варіант 17 — Павло");
            Console.WriteLine(new string('=', 70));

            // Таблиця В, b = 1:
            // 16 випадкових чисел у діапазоні [0; 5]
            // Матриця: 5 x 4
            int[] array = CreateArray(16, 0, 5, N);

            Console.WriteLine("\n===== ЗАВДАННЯ 1. АГРЕГАЦІЯ =====");
            Console.WriteLine("Початковий масив:");
            PrintArray(array);

            AggregateResult result = Aggregate(array);

            Console.WriteLine($"Сума: {result.Sum}");
            Console.WriteLine($"Середнє: {result.Average:F2}");
            Console.WriteLine($"Мінімум: {result.Min}");
            Console.WriteLine($"Індекс мінімуму: {result.MinIndex}");
            Console.WriteLine($"Максимум: {result.Max}");
            Console.WriteLine($"Індекс першого максимуму: {result.MaxIndex}");
            Console.WriteLine($"Кількість нулів: {result.ZeroCount}");

            Console.WriteLine("\n===== ЗАВДАННЯ 2. ФІЛЬТРАЦІЯ =====");
            Console.WriteLine($"Критерій для a = 2: елементи, менші за K % 5 = {K % 5}");
            int[] filtered = FilterLessThan(array, K % 5);

            Console.WriteLine("Новий масив:");
            PrintArray(filtered);

            Console.WriteLine("\n===== ЗАВДАННЯ 3. СЕРІЇ =====");
            SeriesResult series = FindLongestSeries(array);

            if (series.Length == 0)
            {
                Console.WriteLine("Масив порожній — серій немає.");
            }
            else
            {
                Console.WriteLine($"Значення: {series.Value}");
                Console.WriteLine($"Довжина серії: {series.Length}");
                Console.WriteLine($"Індекс початку: {series.StartIndex}");
            }

            Console.WriteLine("\n===== ЗАВДАННЯ 4. ПЕРЕСТАНОВКА НА МІСЦІ =====");
            Console.WriteLine("c = 2 → циклічно зсунути вправо на одну позицію.");

            Console.WriteLine("До:");
            PrintArray(array);

            RotateRightInPlace(array);

            Console.WriteLine("Після:");
            PrintArray(array);

            Console.WriteLine("\n===== ЗАВДАННЯ 5. МАТРИЦЯ =====");
            Console.WriteLine("Матриця 5 x 4, випадкові числа з діапазону [0; 5].");

            int[,] matrix = CreateMatrix(5, 4, 0, 5, N);
            PrintMatrix(matrix);

            int[] rowSums = RowSums(matrix);
            int[] columnMax = ColumnMaxima(matrix);
            int maxSumRow = RowWithMaximumSum(matrix);

            Console.WriteLine("\nСума кожного рядка:");
            PrintIndexedArray(rowSums);

            Console.WriteLine("\nМаксимум кожного стовпця:");
            PrintIndexedArray(columnMax);

            Console.WriteLine($"\nНомер рядка з найбільшою сумою: {maxSumRow}");

            Console.WriteLine("\n===== ЗАВДАННЯ 6. ПЕРЕВІРКА КРАЙОВИХ ВИПАДКІВ =====");
            RunEdgeCaseTests();

            Console.WriteLine("\nГотово.");
        }

        // ---------- Завдання 1 ----------

        static AggregateResult Aggregate(int[] a)
        {
            if (a == null || a.Length == 0)
            {
                return new AggregateResult(
                    0, 0.0, 0, -1, 0, -1, 0
                );
            }

            int sum = 0;
            int min = a[0];
            int max = a[0];
            int minIndex = 0;
            int maxIndex = 0;
            int zeroCount = 0;

            // Один прохід по масиву.
            for (int i = 0; i < a.Length; i++)
            {
                sum += a[i];

                if (a[i] < min)
                {
                    min = a[i];
                    minIndex = i;
                }

                // Знак <, а не <=, забезпечує перший індекс максимуму.
                if (a[i] > max)
                {
                    max = a[i];
                    maxIndex = i;
                }

                if (a[i] == 0)
                {
                    zeroCount++;
                }
            }

            double average = (double)sum / a.Length;

            return new AggregateResult(
                sum, average, min, minIndex, max, maxIndex, zeroCount
            );
        }

        // ---------- Завдання 2 ----------

        static int[] FilterLessThan(int[] a, int limit)
        {
            if (a == null || a.Length == 0)
            {
                return Array.Empty<int>();
            }

            // Перший прохід — рахуємо кількість елементів.
            int count = 0;

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] < limit)
                {
                    count++;
                }
            }

            // Масив створюється одразу потрібного розміру,
            // без порожніх "хвостів".
            int[] result = new int[count];

            // Другий прохід — заповнюємо готовий масив.
            int j = 0;

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] < limit)
                {
                    result[j] = a[i];
                    j++;
                }
            }

            return result;
        }

        // ---------- Завдання 3 ----------

        static SeriesResult FindLongestSeries(int[] a)
        {
            if (a == null || a.Length == 0)
            {
                return new SeriesResult(0, 0, -1);
            }

            int bestValue = a[0];
            int bestLength = 1;
            int bestStart = 0;

            int currentValue = a[0];
            int currentLength = 1;
            int currentStart = 0;

            // Проходимо до кінця масиву.
            for (int i = 1; i < a.Length; i++)
            {
                if (a[i] == currentValue)
                {
                    currentLength++;
                }
                else
                {
                    if (currentLength > bestLength)
                    {
                        bestLength = currentLength;
                        bestValue = currentValue;
                        bestStart = currentStart;
                    }

                    currentValue = a[i];
                    currentLength = 1;
                    currentStart = i;
                }
            }

            // Обов'язково перевіряємо останню серію.
            if (currentLength > bestLength)
            {
                bestLength = currentLength;
                bestValue = currentValue;
                bestStart = currentStart;
            }

            return new SeriesResult(bestValue, bestLength, bestStart);
        }

        // ---------- Завдання 4 ----------

        static void RotateRightInPlace(int[] a)
        {
            if (a == null || a.Length <= 1)
            {
                return;
            }

            // c = 2: циклічний зсув вправо на одну позицію.
            // Другий масив НЕ створюється.
            int last = a[a.Length - 1];

            for (int i = a.Length - 1; i > 0; i--)
            {
                a[i] = a[i - 1];
            }

            a[0] = last;
        }

        // ---------- Завдання 5 ----------

        static int[,] CreateMatrix(int rows, int columns, int min, int max, int seed)
        {
            int[,] matrix = new int[rows, columns];
            Random random = new Random(seed);

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = random.Next(min, max + 1);
                }
            }

            return matrix;
        }

        static int[] RowSums(int[,] matrix)
        {
            if (matrix == null)
            {
                return Array.Empty<int>();
            }

            int rows = matrix.GetLength(0);
            int columns = matrix.GetLength(1);

            int[] sums = new int[rows];

            for (int i = 0; i < rows; i++)
            {
                int sum = 0;

                for (int j = 0; j < columns; j++)
                {
                    sum += matrix[i, j];
                }

                sums[i] = sum;
            }

            return sums;
        }

        static int[] ColumnMaxima(int[,] matrix)
        {
            if (matrix == null)
            {
                return Array.Empty<int>();
            }

            int rows = matrix.GetLength(0);
            int columns = matrix.GetLength(1);

            if (rows == 0 || columns == 0)
            {
                return new int[columns];
            }

            int[] maxima = new int[columns];

            for (int j = 0; j < columns; j++)
            {
                maxima[j] = matrix[0, j];

                for (int i = 1; i < rows; i++)
                {
                    if (matrix[i, j] > maxima[j])
                    {
                        maxima[j] = matrix[i, j];
                    }
                }
            }

            return maxima;
        }

        static int RowWithMaximumSum(int[,] matrix)
        {
            if (matrix == null || matrix.GetLength(0) == 0)
            {
                return -1;
            }

            int rows = matrix.GetLength(0);
            int columns = matrix.GetLength(1);

            int bestRow = 0;
            int bestSum = int.MinValue;

            for (int i = 0; i < rows; i++)
            {
                int sum = 0;

                for (int j = 0; j < columns; j++)
                {
                    sum += matrix[i, j];
                }

                // Якщо суми однакові, залишається перший рядок.
                if (sum > bestSum)
                {
                    bestSum = sum;
                    bestRow = i;
                }
            }

            return bestRow;
        }

        // ---------- Завдання 6 ----------

        static void RunEdgeCaseTests()
        {
            int[] empty = Array.Empty<int>();
            int[] one = { 3 };
            int[] equal = { 2, 2, 2, 2 };

            TestArray("Порожній масив", empty);
            TestArray("Один елемент", one);
            TestArray("Усі елементи однакові", equal);
        }

        static void TestArray(string name, int[] a)
        {
            Console.WriteLine($"\n{name}:");
            PrintArray(a);

            AggregateResult aggregate = Aggregate(a);
            SeriesResult series = FindLongestSeries(a);
            int[] filtered = FilterLessThan(a, K % 5);

            Console.WriteLine(
                $"Агрегація: сума={aggregate.Sum}, " +
                $"minIndex={aggregate.MinIndex}, " +
                $"maxIndex={aggregate.MaxIndex}, " +
                $"нулів={aggregate.ZeroCount}"
            );

            Console.WriteLine(
                $"Серія: значення={series.Value}, " +
                $"довжина={series.Length}, " +
                $"початок={series.StartIndex}"
            );

            Console.WriteLine("Фільтрація:");
            PrintArray(filtered);

            int[] copy = CopyArray(a);
            RotateRightInPlace(copy);

            Console.WriteLine("Перестановка вправо:");
            PrintArray(copy);
        }

        // ---------- Допоміжні методи ----------

        static int[] CreateArray(int length, int min, int max, int seed)
        {
            int[] a = new int[length];
            Random random = new Random(seed);

            for (int i = 0; i < a.Length; i++)
            {
                a[i] = random.Next(min, max + 1);
            }

            return a;
        }

        static int[] CopyArray(int[] source)
        {
            if (source == null)
            {
                return Array.Empty<int>();
            }

            int[] copy = new int[source.Length];

            for (int i = 0; i < source.Length; i++)
            {
                copy[i] = source[i];
            }

            return copy;
        }

        static void PrintArray(int[] a)
        {
            if (a == null || a.Length == 0)
            {
                Console.WriteLine("[порожній масив]");
                return;
            }

            Console.Write("[ ");

            for (int i = 0; i < a.Length; i++)
            {
                Console.Write(a[i]);

                if (i < a.Length - 1)
                {
                    Console.Write(", ");
                }
            }

            Console.WriteLine(" ]");
        }

        static void PrintIndexedArray(int[] a)
        {
            if (a == null || a.Length == 0)
            {
                Console.WriteLine("[порожній масив]");
                return;
            }

            for (int i = 0; i < a.Length; i++)
            {
                Console.WriteLine($"[{i}] = {a[i]}");
            }
        }

        static void PrintMatrix(int[,] matrix)
        {
            if (matrix == null)
            {
                Console.WriteLine("[матриця відсутня]");
                return;
            }

            int rows = matrix.GetLength(0);
            int columns = matrix.GetLength(1);

            Console.WriteLine();

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    Console.Write($"{matrix[i, j],5}");
                }

                Console.WriteLine();
            }
        }
    }

    // Результат завдання 1.
    class AggregateResult
    {
        public int Sum { get; }
        public double Average { get; }
        public int Min { get; }
        public int MinIndex { get; }
        public int Max { get; }
        public int MaxIndex { get; }
        public int ZeroCount { get; }

        public AggregateResult(
            int sum,
            double average,
            int min,
            int minIndex,
            int max,
            int maxIndex,
            int zeroCount)
        {
            Sum = sum;
            Average = average;
            Min = min;
            MinIndex = minIndex;
            Max = max;
            MaxIndex = maxIndex;
            ZeroCount = zeroCount;
        }
    }

    // Результат завдання 3.
    class SeriesResult
    {
        public int Value { get; }
        public int Length { get; }
        public int StartIndex { get; }

        public SeriesResult(int value, int length, int startIndex)
        {
            Value = value;
            Length = length;
            StartIndex = startIndex;
        }
    }
}
